Setup Dev system
----------------

Here you can see how to configure your server running ubuntu 18.04 to run Django-CRM
