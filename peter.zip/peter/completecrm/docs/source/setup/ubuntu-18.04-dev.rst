Setup Dev system
----------------

Here you can see how to configure your dev machine to run Django-CRM
