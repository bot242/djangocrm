Packages Used
=============

.. class:: center

	django

	celery
	
	django-simple-pagination
	
	django-compressor
	
	sorl-thumbnail
	
	django-phonenumber-field
	
	phonenumbers
	
	django-storages
	
	psycopg2-binary
	
	arrow
	
	requests
	
	boto3
	
	lxml
	
	cssselect
	
	xlrd
	
	xlwt
	
	openpyxl
	
	pdfkit
	
	redis
	
	coverage
	
	raven
	
	sorl-thumbnail
	
	pytest
	
	pytest-django
	
	codacy-coverage
	
	django-haystack
	
	elasticsearch
