============
Contact List
============

Use contact list to import bulk contacts into single list. In create page, you can download the sample file for your reference.

It will be useful, at the time of sending a campaign. In contact list page, you can see name of the contact list, valid & invalid contacts of the list, bounced contacts, failed contacts, duplicate contacts.

Click on the contact list title, to access view page. In view page, you can see detailed contacts info with count. Here you can either edit or delete contacts.
