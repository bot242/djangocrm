========
Contacts
========


All the uploaded contacts will be appeared here. Here you can able to see valid, bounced, failed contacts with the count. You delete existing contacts from the list page.

You filter contacts by email, domain name, created by, contact list. Click on each tab, to check contacts in a detailed view.
