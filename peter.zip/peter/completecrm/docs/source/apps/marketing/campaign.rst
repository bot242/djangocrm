========
Campaign
========

It will be useful to send promotional campaigns for multiple contacts and to generate more no. of leads. In campaign create page, you can choose existing contact list & email templates. 

Here you can choose option as whether to receive your replies to your account or CRM application. You can specify the placeholders in the template. Placeholders are like name, email, company etc.

In the campaign view page, you can take a glance of everything. Like how many bounced contacts, unsubscribed users, opened emails etc. If there are any links in your email, you can also track which users opened that link or not.

You can filter campaigns by name, created by.

