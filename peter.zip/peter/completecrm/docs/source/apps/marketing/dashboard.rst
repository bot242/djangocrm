=========
Dashboard
=========

Here you can see the general overview of your sales activity at a glance. Which display statistical view of latest 5 campaigns with required data. At bottom of this report, you can latest 5 records of contact list & campaigns

* **Recent Contact List -** Here you can see contact list name, it’s tags. From here, you can switch to contact list view page.

* **Recent Campaigns -** These are latest 5 campaigns with info of campaign title, tags, created on date. Click on the campaign title, to check it’s detailed view.
