===============
Email Templates
===============

Email templates are used at the time of campaign creation. From the list page, click on the plus(+) icon to create a campaign using that template. 

Click on eye icon, to see how the template will look like. You can filter email templates by name, created by.
