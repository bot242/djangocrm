=====
Leads
=====

Leads plays a crucial role in the sales module. If anyone is interested towards your services, you can add them here. These leads are not confirmed. Once a lead is qualified, you can convert them as an account.

You can create leads in two ways, 

* **By creating manually -** You can create only one lead at a time. 
* **By uploading CSV file -** You can create more than one lead in a single click.

There are 2 types of leads, open & closed leads. Open leads are the active leads. From the lead list page, you can view, update or delete a lead. 

From lead list page, click on the lead title, to check lead quick view. By clicking on the eye icon from table, you can see the detailed view of a lead. 
