========
Accounts
========

Accounts are nothing but converted leads. It has all the information of the company like Contacts, Opportunities, Cases, Tasks, Invoices, Mails history associated with this account.

Here you can able to create a new account, check the existing accounts and update accounts. Here we have 2 types of accounts, Open & Closed accounts. Open accounts are the active accounts. You can filter accounts by account title, city, tags. 

In the account view page, you can attach any kind of documents and you can add comments if you have any updates.
