======
Events
======

It is to schedule calls or meetings. There are 2 types of events,

Recurring - Based on the day selection, start & end dates, you can create recurring events 
Non-recurring - You can create events for a specific date

When you assign an event for an user, they will receive a notification email reg: the event. You can upload attachments in the events view page. After completion of call or meeting, they can add comments in the event view page. 

You can filter events by name, created by, assigned users, date of meeting.
