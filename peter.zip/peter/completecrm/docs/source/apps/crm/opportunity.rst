===========
Opportunity
===========


Requested services of the company are meant to be opportunities. New opportunities can be added and can be assigned to accounts & contacts.

You can access opportunity view, edit and delete from the list page. In the list page, you can check which accounts are linked to opportunities.

In the view page, you can check the detailed info an opportunity, uploaded attachments and comments.
