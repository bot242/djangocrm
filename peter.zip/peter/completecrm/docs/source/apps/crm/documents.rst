=========
Documents
=========


Here you can upload any kind of documents and assign to either team or individual person. In list page, you can see existing documents in a grid view with view, edit, delete and download options.

Assigned users can able to manage and download the documents from the list page. You can filter documents by it’s name, status and assigned users.

