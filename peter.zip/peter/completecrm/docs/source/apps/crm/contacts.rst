========
Contacts
========

Contacts relate to individual persons of the company. Each account or lead may have more than one contact and one contact may associate with multiple accounts. 

You can create a new contact, manage existing contacts. In the contact view page, you can see the detailed view with associated Tasks, comments and attachments if any.

You can filter contacts by name, city and assigned user.
