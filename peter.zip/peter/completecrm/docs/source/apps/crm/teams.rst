=====
Teams
=====

You can group users into teams. Instead of assigning leads, accounts etc. to multiple people, you can create a team and assign them. For ex: You can create teams like sales, marketing etc.

In teams list page, you can see which users are involved in each team. From list page, you can access team view, edit, delete features.

You can filter teams by name, created by, assigned users.
