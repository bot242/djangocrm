========
Invoices
========

Which helps to generate a bill for your client or account based on the services you have provided. By doing this, you can measure how much of revenue is generating for your company. You can create invoices for individuals and assign to clients. 

You can save invoice as either draft or send. Total there are 5 options in the invoice - Draft, Send, Pending, Paid, Cancel.

* **Draft -** It will be used for future purpose
* **Send -** If you choose the invoice status as send, then it will be shared with the respective client
* **Pending -** Waiting for the payment
* **Paid -** Invoice amount has been paid by client
* **Cancel -** It will close the invoice

From invoice list page, you can change the invoice status, view, manage invoices. You can filer invoices by title, invoice number, created by, assigned users, status, total amount.
