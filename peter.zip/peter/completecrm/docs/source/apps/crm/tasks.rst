=====
Tasks
=====

Project requirements are called as tasks. Each project will be divided into multiple tasks and if you finish tasks on time, then you can be able to complete a project with good productivity.

You can create tasks with deadlines to track easily. From the task list page, you can create a new task, view, update and delete a task. In the task view page, you can check the uploaded documents and comments section. 
