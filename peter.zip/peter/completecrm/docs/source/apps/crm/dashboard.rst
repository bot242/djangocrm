=========
Dashboard
=========

This is the first page you'll see when you login. Here you can see the general overview of your sales activity at a glance. Which displays count of your total Accounts, Contacts, Leads, Opportunities, Recently created accounts & opportunities.

* **Recent Accounts:** Here you can see recently created 10 accounts with respective info like account title, tags, assigned user. By clicking on account title you will be redirected to account view page with detailed info.

* **Recent Opportunities:** Here you can see recently created 10 opportunities with respective info like opportunity title, tags, assigned user. By clicking on opportunity title you will be redirected to opportunity view page with detailed info.


