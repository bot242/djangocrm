=====
Cases
=====


Any customer issues or help will be logged here. Each case will be assigned to respective team or user. Cases can be individual or it can be related to accounts or contacts.

From cases list page, you can create a new case and you can manage existing cases like edit, delete and close cases.

You can filter cases by its name, status, priority and assigned users.
