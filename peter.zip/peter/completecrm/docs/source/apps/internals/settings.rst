========
Settings
========

In settings page, you can add contacts, block domains, block emails. You can access this page from user drop down. Only admins can able to access settings page.

If you add any contacts in this page, those users will receive an email if anyone in the organization runs a campaign. If you block any domain or email, then they don’t receive any campaign related emails.
