=======
Profile
=======

You can view/edit basic info of an user. You can access this page from user drop down. In this page, you can see the name of your account, email, in which team you are involved, which module permissions you have like sales & marketing, profile picture.
