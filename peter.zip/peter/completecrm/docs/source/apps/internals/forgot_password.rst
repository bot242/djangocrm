===============
Forgot Password
===============

From the login page, you can request for forgot password. To reset the password, you have to specify your email. After that, you will receive an email with instructions to set a new password for your account. 
