===============
Change Password
===============

For security purpose, you can change the password for your account. You can navigate to change password page, from user drop down. You have to specify new & confirm password as per the instructions specified in this page.  

