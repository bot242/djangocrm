=====
Users
=====

To access the CRM, you can create users here with required permissions like user role (Admin & User), module level permissions (sales & marketing). Based on these two, user can access CRM features, when they logged in.

There are 2 types of users, active & inactive(deleted users). From list page, you activate or deactivate user account and you can reset the password for an user.
