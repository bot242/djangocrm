from plyer import notification 
notification.notify(
    title="Message from zoogle",
    message="testing notify",
)